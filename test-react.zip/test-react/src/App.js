import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import List from './List';
import './App.css';

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      term: '',
      items: []
    };

  }
  onChange = (e) => {
    this.setState({ term: e.target.value });
  }
  onSubmit = (e) => {
    e.preventDefault()
    this.setState({
      term: '',
      items: [...this.state.items, this.state.term]
    });

    // if (this.setState() === '') {
    //   return (
    //     <div className="alert alert-danger" role="alert">
    //       This is a danger alert—check it out!
    //     </div>

    //   )

    // }

  }
  
  onClick = (e) => {
    e.preventDefault()
    this.item(e.delete)
  }



  render() {
    return (
      <div className="container">
        <form className="App" onSubmit={this.onSubmit}>
          <input value={this.state.term} onChange={this.onChange} placeholder='Enter Your Name...' />
          <button className='btn-danger'>Submit</button>
        </form>
        <List items={this.state.items} />


      </div>


    );


  }
}
