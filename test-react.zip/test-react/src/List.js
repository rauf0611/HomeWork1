import React from 'react';
import App from './App';
import './List.css';


const List = props => (

    

    <table>
        <tr>
            <th>
                Name :
            </th>
        </tr>
        <tr>
            {props.items.map((item, index) => <th key={index}>{item}          
              <span onClick={item}>x</span>
            </th>)}
        </tr>
    </table>

);

export default List;